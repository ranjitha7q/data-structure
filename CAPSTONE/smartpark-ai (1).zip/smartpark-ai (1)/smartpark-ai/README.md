# SmartPark AI
### Advanced Data Structure-Based Smart Parking Management and Predictive Space Allocation System
**CSA0311 – Data Structures Project**

A fully interactive, working simulation website — no backend, no build step, no npm install required.
Plain HTML / CSS / JavaScript, so it opens and runs instantly.

## How to run it

**Option 1 — Just open it**
Double-click `index.html` (or right-click → Open with your browser).

**Option 2 — VS Code (recommended)**
1. Open this folder in VS Code (`File → Open Folder…`).
2. Install the **Live Server** extension (by Ritwick Dey) if you don't have it.
3. Right-click `index.html` → **Open with Live Server**.
4. The site opens at `http://127.0.0.1:5500` (or similar) and hot-reloads as you edit.

> Live Server isn't required — the app also works by opening `index.html` directly,
> since everything runs client-side with no server calls.

## Project structure
```
smartpark-ai/
├── index.html              # Page shell + navigation + all page sections
├── css/
│   └── style.css           # Smart-city dashboard theme
├── js/
│   ├── dataStructures.js   # Real implementations: PriorityQueue, WaitingQueue,
│   │                       #   LinkedList, VehicleHashTable, ParkingGraph (Dijkstra), TreeNode
│   ├── data.js              # Demo/seed data generation (slots, graph, tree, demand bands)
│   └── app.js               # State, allocation/billing/queue logic, all page rendering
└── README.md
```

## Data structures demonstrated (and where)
| Data Structure | Used For | Where in the UI |
|---|---|---|
| Array | Parking slot storage & scanning | Data Structures Visualizer, Algorithm Comparison |
| Priority Queue (binary max-heap) | Smart slot selection by score | Smart Slot Allocation |
| Queue (priority-ordered) | Waiting vehicles | Waiting Queue |
| Hash Table (Map) | O(1) vehicle lookup | Vehicle Search |
| Singly Linked List | Parking history | Parking History |
| Graph + Dijkstra's Algorithm | Shortest route to a slot | Parking Map & Navigation |
| Tree | Zone → Slot → Type hierarchy | Data Structures Visualizer |

## Notes for your viva / report
- Every "Data Structure Used" badge in the UI is real — you can open `js/dataStructures.js`
  and `js/app.js` to show the actual implementation while demoing the corresponding feature.
- Predictive analytics, environmental-impact, and algorithm-comparison numbers are clearly
  simulated/demo values, generated live by the app — not hard-coded fake numbers pretending
  to be real-world measurements.
- The Admin / Simulation panel lets you trigger a "slot failure" to demonstrate dynamic
  reallocation live, and fast-forward parked vehicles' time to demonstrate billing.

## Customizing
- Number of zones/slots: edit `ZONES` and `SLOTS_PER_ZONE` in `js/data.js`.
- Parking rate: edit `RATE_PER_HOUR` in `js/data.js`.
- Scoring weights: edit `computeSmartScore()` in `js/app.js`.
