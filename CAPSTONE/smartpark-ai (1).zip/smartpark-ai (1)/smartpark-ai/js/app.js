/* =========================================================
   SmartPark AI — Application Logic
   ========================================================= */

const $ = sel => document.querySelector(sel);
const $all = sel => Array.from(document.querySelectorAll(sel));
const clamp = (v, min, max) => Math.max(min, Math.min(max, v));
const fmtTime = ts => new Date(ts).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit", second: "2-digit" });
const fmtDateTime = ts => new Date(ts).toLocaleString();

/* ---------------- Global State ---------------- */
const state = {
  activeTab: "dashboard",
  slots: buildInitialSlots(),
  vehicles: new Map(),         // parkingId -> vehicle record
  hashTable: new VehicleHashTable(),
  waitingQueue: new WaitingQueue(),
  history: new LinkedList(),
  parkingIdCounter: 1001,
  lastAllocation: null,        // {vehicle, slot, scoredList}
  lastFailureLog: [],
  algoStats: null,
  charts: {},
};
state.graph = buildGraph(state.slots);
state.tree = buildTree(state.slots);

// Seed a few slots with placeholder vehicles so the demo isn't empty
(function seedDemoVehicles() {
  const occupiedSlots = state.slots.filter(s => s.status === "Occupied");
  occupiedSlots.forEach((slot, i) => {
    const parkingId = `P${state.parkingIdCounter++}`;
    const vType = choice(VEHICLE_TYPES);
    const vehicle = {
      parkingId,
      vehicleNumber: `TN${randInt(10, 99)}${choice(["AB","CD","EF","GH","KL"])}${randInt(1000,9999)}`,
      ownerName: choice(["R. Kumar","S. Priya","A. Sharma","M. Iqbal","D. Rao","V. Nair","T. Singh","J. Fernandes"]),
      vehicleType: vType,
      entryTime: Date.now() - randInt(10, 240) * 60000,
      slotId: slot.id,
      status: "Parked",
    };
    slot.vehicleNumber = vehicle.vehicleNumber;
    slot.parkingId = parkingId;
    state.vehicles.set(parkingId, vehicle);
    state.hashTable.set(vehicle.vehicleNumber, vehicle);
    state.hashTable.set(parkingId, vehicle);
  });
})();

/* ---------------- Toast ---------------- */
function toast(msg, type = "success") {
  const el = document.createElement("div");
  el.className = `toast ${type}`;
  el.textContent = msg;
  $("#toast-container").appendChild(el);
  setTimeout(() => el.remove(), 4200);
}

/* ---------------- Core Domain Logic ---------------- */
function compatibilityScore(slotType, vehicleType) {
  if (slotType === "Regular") {
    return ["Car", "Bike", "SUV"].includes(vehicleType) ? 95 : 55;
  }
  if (slotType === vehicleType) return 100;
  return 20;
}

function computeSmartScore(slot, vehicleType) {
  const distScore = clamp(100 - (slot.distance / 200) * 100, 0, 100);
  const walkScore = clamp(100 - (slot.walkDistance / 100) * 100, 0, 100);
  const congScore = clamp(100 - slot.congestion, 0, 100);
  const compatScore = compatibilityScore(slot.type, vehicleType);
  const futureScore = randInt(40, 95);
  const total = 0.4 * distScore + 0.2 * walkScore + 0.2 * congScore + 0.1 * compatScore + 0.1 * futureScore;
  return {
    total: Math.round(total),
    distScore: Math.round(distScore),
    walkScore: Math.round(walkScore),
    congScore: Math.round(congScore),
    compatScore,
    futureScore,
  };
}

function getAvailableSlots(excludeIds = []) {
  return state.slots.filter(s => s.status === "Available" && !excludeIds.includes(s.id));
}

// Uses the real PriorityQueue class to pick the best slot
function allocateBestSlot(vehicleType, excludeIds = []) {
  const available = getAvailableSlots(excludeIds);
  if (available.length === 0) return null;

  const pq = new PriorityQueue();
  const scored = [];
  available.forEach(s => {
    const sc = computeSmartScore(s, vehicleType);
    s.score = sc.total;
    s.scoreBreakdown = sc;
    pq.insert({ id: s.id, score: sc.total, payload: s });
    scored.push(s);
  });
  scored.sort((a, b) => b.score - a.score);
  const best = pq.extractMax();
  return { slot: best.payload, scoredList: scored, pq };
}

function buildReason(slot) {
  const reasons = [];
  if (slot.scoreBreakdown?.distScore >= 60) reasons.push("Shortest estimated travel time");
  if (slot.scoreBreakdown?.congScore >= 60) reasons.push("Low congestion");
  if (slot.scoreBreakdown?.compatScore >= 90) reasons.push("Ideal match for vehicle type");
  if (slot.scoreBreakdown?.futureScore >= 60) reasons.push("Good predicted future availability");
  if (reasons.length === 0) reasons.push("Best available trade-off among current options");
  return reasons;
}

function assignVehicleToSlot(vehicle, slot, scoredList) {
  slot.status = "Occupied";
  slot.vehicleNumber = vehicle.vehicleNumber;
  slot.parkingId = vehicle.parkingId;
  vehicle.slotId = slot.id;
  vehicle.status = "Parked";
  vehicle.allocatedAt = Date.now();
  vehicle.allocationReason = buildReason(slot);
  state.lastAllocation = { vehicle: { ...vehicle }, slot: { ...slot }, scoredList: scoredList || null };
}

function registerVehicle(form) {
  const parkingId = `P${state.parkingIdCounter++}`;
  const vehicle = {
    parkingId,
    vehicleNumber: form.vehicleNumber.trim().toUpperCase(),
    ownerName: form.ownerName.trim(),
    vehicleType: form.vehicleType,
    specialRequirement: form.specialRequirement || "None",
    entryTime: Date.now(),
    slotId: null,
    status: "Registered",
  };
  state.vehicles.set(parkingId, vehicle);
  state.hashTable.set(vehicle.vehicleNumber, vehicle);
  state.hashTable.set(parkingId, vehicle);

  const alloc = allocateBestSlot(vehicle.vehicleType);
  if (alloc) {
    assignVehicleToSlot(vehicle, alloc.slot, alloc.scoredList);
    toast(`Parking ID ${parkingId} → Slot ${alloc.slot.id} allocated (score ${alloc.slot.score}/100)`, "success");
  } else {
    const priority = vehicle.vehicleType === "VIP" ? "VIP" : vehicle.vehicleType === "Disabled" ? "Disabled" : "Regular";
    state.waitingQueue.enqueue({ parkingId, vehicleNumber: vehicle.vehicleNumber, priority });
    vehicle.status = "Waiting";
    toast(`No slots available — ${parkingId} added to waiting queue`, "warn");
  }
  return vehicle;
}

function serveWaitingQueue(silent = false) {
  if (state.waitingQueue.isEmpty()) { if (!silent) toast("Waiting queue is empty", "warn"); return; }
  const next = state.waitingQueue.dequeue();
  const vehicle = state.vehicles.get(next.parkingId);
  if (!vehicle) return;
  const alloc = allocateBestSlot(vehicle.vehicleType);
  if (alloc) {
    assignVehicleToSlot(vehicle, alloc.slot, alloc.scoredList);
    toast(`Slot ${alloc.slot.id} allocated to waiting vehicle ${vehicle.vehicleNumber}`, "success");
  } else {
    state.waitingQueue.enqueue(next);
    if (!silent) toast("Still no slots available for waiting vehicles", "error");
  }
}

function exitVehicle(parkingId) {
  const vehicle = state.vehicles.get(parkingId);
  if (!vehicle || vehicle.status !== "Parked") return null;
  const slot = state.slots.find(s => s.id === vehicle.slotId);
  const durationHrs = Math.max(0.25, (Date.now() - vehicle.entryTime) / 3600000);
  const amount = Math.ceil(durationHrs) * RATE_PER_HOUR;

  vehicle.exitTime = Date.now();
  vehicle.status = "Exited";
  vehicle.duration = durationHrs;
  vehicle.amount = amount;
  vehicle.exitSlotId = vehicle.slotId;

  state.history.insertFront({ ...vehicle });

  if (slot) { slot.status = "Available"; slot.vehicleNumber = null; slot.parkingId = null; }
  serveWaitingQueue(true);
  return vehicle;
}

function triggerSlotFailure(slotId) {
  const slot = state.slots.find(s => s.id === slotId);
  if (!slot || slot.status !== "Occupied") { toast("Pick an occupied slot to simulate a failure", "warn"); return; }
  const vehicle = state.vehicles.get(slot.parkingId);
  const oldId = slot.id;
  slot.status = "Reserved"; // temporarily blocked
  slot.vehicleNumber = null; slot.parkingId = null;

  let logLine = `${oldId} became unavailable.`;
  if (vehicle) {
    const alloc = allocateBestSlot(vehicle.vehicleType, [oldId]);
    if (alloc) {
      assignVehicleToSlot(vehicle, alloc.slot, alloc.scoredList);
      logLine += ` Vehicle ${vehicle.parkingId} auto-reassigned to ${alloc.slot.id}.`;
      toast(logLine, "warn");
    } else {
      vehicle.status = "Waiting"; vehicle.slotId = null;
      state.waitingQueue.enqueue({ parkingId: vehicle.parkingId, vehicleNumber: vehicle.vehicleNumber, priority: "Regular" });
      logLine += ` No alternate slot — ${vehicle.parkingId} moved to waiting queue.`;
      toast(logLine, "error");
    }
  }
  state.lastFailureLog.unshift({ time: Date.now(), text: logLine });
  state.lastFailureLog = state.lastFailureLog.slice(0, 6);
}

function resetSimulation() {
  state.slots = buildInitialSlots();
  state.graph = buildGraph(state.slots);
  state.tree = buildTree(state.slots);
  state.vehicles = new Map();
  state.hashTable = new VehicleHashTable();
  state.waitingQueue = new WaitingQueue();
  state.history = new LinkedList();
  state.parkingIdCounter = 1001;
  state.lastAllocation = null;
  state.lastFailureLog = [];
  state.algoStats = null;
  toast("Simulation reset", "success");
}

/* ---------------- Algorithm Comparison Simulation ---------------- */
function runAlgorithmComparison() {
  const snapshot = () => JSON.parse(JSON.stringify(state.slots));
  const vehicleTypesPool = () => Array.from({ length: 12 }, () => choice(VEHICLE_TYPES));
  const results = {};

  // 1. First Available — linear scan, stops at first Available slot
  (function firstAvailable() {
    const slots = snapshot();
    let comparisons = 0, totalDist = 0, assigned = 0;
    vehicleTypesPool().forEach(() => {
      for (let i = 0; i < slots.length; i++) {
        comparisons++;
        if (slots[i].status === "Available") {
          slots[i].status = "Occupied";
          totalDist += slots[i].distance;
          assigned++;
          break;
        }
      }
    });
    const occupiedCount = slots.filter(s => s.status === "Occupied").length;
    results["First Available"] = {
      searchTime: +(comparisons * 0.015).toFixed(2),
      waitingTime: assigned ? +((totalDist / assigned) / 50).toFixed(2) : 0,
      utilization: +((occupiedCount / slots.length) * 100).toFixed(1),
    };
  })();

  // 2. Nearest Slot — linear scan for minimum distance
  (function nearestSlot() {
    const slots = snapshot();
    let comparisons = 0, totalDist = 0, assigned = 0;
    vehicleTypesPool().forEach(() => {
      let bestIdx = -1, bestDist = Infinity;
      for (let i = 0; i < slots.length; i++) {
        comparisons++;
        if (slots[i].status === "Available" && slots[i].distance < bestDist) {
          bestDist = slots[i].distance; bestIdx = i;
        }
      }
      if (bestIdx >= 0) { slots[bestIdx].status = "Occupied"; totalDist += bestDist; assigned++; }
    });
    const occupiedCount = slots.filter(s => s.status === "Occupied").length;
    results["Nearest Slot"] = {
      searchTime: +(comparisons * 0.015).toFixed(2),
      waitingTime: assigned ? +((totalDist / assigned) / 50).toFixed(2) : 0,
      utilization: +((occupiedCount / slots.length) * 100).toFixed(1),
    };
  })();

  // 3. Priority Queue (distance-only priority)
  (function priorityQueueOnly() {
    const slots = snapshot();
    let ops = 0, totalDist = 0, assigned = 0;
    vehicleTypesPool().forEach(() => {
      const pq = new PriorityQueue();
      slots.filter(s => s.status === "Available").forEach(s => {
        pq.insert({ id: s.id, score: 200 - s.distance, payload: s });
        ops++; // insert op
      });
      const best = pq.extractMax();
      ops++; // extract op
      if (best) { best.payload.status = "Occupied"; totalDist += best.payload.distance; assigned++; }
    });
    const occupiedCount = slots.filter(s => s.status === "Occupied").length;
    results["Priority Queue"] = {
      searchTime: +(ops * (Math.log2(slots.length + 1)) * 0.02).toFixed(2),
      waitingTime: assigned ? +((totalDist / assigned) / 50).toFixed(2) : 0,
      utilization: +((occupiedCount / slots.length) * 100).toFixed(1),
    };
  })();

  // 4. Proposed: Smart Score + Priority Queue
  (function proposed() {
    const slots = snapshot();
    let ops = 0, totalDist = 0, assigned = 0, totalScore = 0;
    vehicleTypesPool().forEach(vType => {
      const pq = new PriorityQueue();
      slots.filter(s => s.status === "Available").forEach(s => {
        const sc = computeSmartScore(s, vType);
        pq.insert({ id: s.id, score: sc.total, payload: s });
        ops++;
      });
      const best = pq.extractMax();
      ops++;
      if (best) {
        best.payload.status = "Occupied";
        totalDist += best.payload.distance;
        totalScore += best.score;
        assigned++;
      }
    });
    const occupiedCount = slots.filter(s => s.status === "Occupied").length;
    results["Proposed Algorithm"] = {
      searchTime: +(ops * (Math.log2(slots.length + 1)) * 0.02).toFixed(2),
      waitingTime: assigned ? +((totalDist / assigned) / 50).toFixed(2) : 0,
      utilization: +((occupiedCount / slots.length) * 100).toFixed(1),
      avgScore: assigned ? Math.round(totalScore / assigned) : 0,
    };
  })();

  state.algoStats = results;
  return results;
}

/* ---------------- Navigation / Tabs ---------------- */
const TAB_TITLES = {
  dashboard: "Dashboard",
  register: "Vehicle Registration",
  allocation: "Smart Slot Allocation",
  map: "Parking Map & Navigation",
  queue: "Waiting Queue",
  search: "Vehicle Search",
  billing: "Billing & Transactions",
  history: "Parking History",
  predict: "Predictive Analytics",
  compare: "Algorithm Comparison",
  dsviz: "Data Structures Visualizer",
  admin: "Admin / Simulation Panel",
  info: "Project Information",
};

function setActiveTab(tab) {
  state.activeTab = tab;
  $all(".nav-item").forEach(b => b.classList.toggle("active", b.dataset.tab === tab));
  $all(".tab-panel").forEach(p => p.classList.toggle("active", p.id === `tab-${tab}`));
  $("#topbar-title").textContent = TAB_TITLES[tab];
  renderActiveTab();
}

function renderActiveTab() {
  const fn = RENDERERS[state.activeTab];
  if (fn) fn();
}

function refreshIfVisible(tabs) {
  if (tabs.includes(state.activeTab)) renderActiveTab();
}

/* ================================================================
   RENDER FUNCTIONS
   ================================================================ */

function destroyChart(key) {
  if (state.charts[key]) { state.charts[key].destroy(); delete state.charts[key]; }
}

/* ---------- Dashboard ---------- */
function renderDashboard() {
  const total = state.slots.length;
  const available = state.slots.filter(s => s.status === "Available").length;
  const occupied = state.slots.filter(s => s.status === "Occupied").length;
  const reserved = state.slots.filter(s => s.status === "Reserved").length;
  const waiting = state.waitingQueue.size();
  const occupancyPct = Math.round((occupied / total) * 100);
  const currentBand = DEMAND_BANDS[new Date().getHours() % DEMAND_BANDS.length];
  const peak = DEMAND_BANDS.reduce((a, b) => (b.occupancy > a.occupancy ? b : a));
  const exitedVehicles = state.history.toArray();
  const avgParkTime = exitedVehicles.length
    ? (exitedVehicles.reduce((a, v) => a + v.duration, 0) / exitedVehicles.length).toFixed(2)
    : "—";

  $("#tab-dashboard").innerHTML = `
    <div class="grid grid-4">
      ${statCard("🅿️", "Total Parking Slots", total)}
      ${statCard("🟢", "Available Slots", available)}
      ${statCard("🔴", "Occupied Slots", occupied)}
      ${statCard("🟡", "Reserved / Blocked", reserved)}
      ${statCard("⏳", "Waiting Vehicles", waiting)}
      ${statCard("📊", "Current Occupancy", occupancyPct + "%")}
      ${statCard("🔮", "Predicted Occupancy", currentBand.occupancy + "%")}
      ${statCard("⏱️", "Avg Parking Time (hrs)", avgParkTime)}
    </div>

    <div class="section-title">Live Analytics</div>
    <div class="grid grid-2">
      <div class="card">
        <h3>Occupancy vs Predicted Demand (by time band)</h3>
        <div class="chart-box"><canvas id="chartOccupancy"></canvas></div>
      </div>
      <div class="card">
        <h3>Vehicle Type Distribution</h3>
        <div class="chart-box"><canvas id="chartVehicleType"></canvas></div>
      </div>
    </div>

    <div class="section-title">Peak Insight</div>
    <div class="card">
      <div class="kv"><span>Peak Parking Period</span><span><b>${peak.label}</b></span></div>
      <div class="kv"><span>Predicted Peak Occupancy</span><span><b>${peak.occupancy}%</b></span></div>
      <div class="kv"><span>Average Allocation Time (Priority Queue, O(log n))</span><span><b>~${(Math.log2(available + 1) * 3 + 4).toFixed(1)} ms</b></span></div>
      <div class="kv"><span>Vehicles Currently Parked</span><span><b>${[...state.vehicles.values()].filter(v => v.status === "Parked").length}</b></span></div>
    </div>
  `;

  destroyChart("occupancy"); destroyChart("vtype");
  state.charts.occupancy = new Chart($("#chartOccupancy"), {
    type: "line",
    data: {
      labels: DEMAND_BANDS.map(b => b.label),
      datasets: [
        { label: "Predicted Demand %", data: DEMAND_BANDS.map(b => b.occupancy), borderColor: "#4f8cff", backgroundColor: "rgba(79,140,255,0.15)", fill: true, tension: 0.35 },
        { label: "Current Live Occupancy %", data: DEMAND_BANDS.map(() => occupancyPct), borderColor: "#33c481", borderDash: [6, 4], fill: false, tension: 0 },
      ],
    },
    options: chartOpts(),
  });

  const typeCounts = {};
  VEHICLE_TYPES.forEach(t => typeCounts[t] = 0);
  [...state.vehicles.values()].filter(v => v.status === "Parked").forEach(v => typeCounts[v.vehicleType]++);
  state.charts.vtype = new Chart($("#chartVehicleType"), {
    type: "doughnut",
    data: {
      labels: Object.keys(typeCounts),
      datasets: [{ data: Object.values(typeCounts), backgroundColor: ["#4f8cff", "#7c5cff", "#33c481", "#f2b84b", "#a877f0", "#ef5b6b"] }],
    },
    options: { plugins: { legend: { labels: { color: "#93a1bd" } } } },
  });
}

function statCard(icon, label, value) {
  return `<div class="card"><div class="card-header"><h3>${label}</h3><span class="stat-icon">${icon}</span></div><div class="stat-value">${value}</div></div>`;
}

function chartOpts() {
  return {
    plugins: { legend: { labels: { color: "#93a1bd" } } },
    scales: {
      x: { ticks: { color: "#93a1bd" }, grid: { color: "#223049" } },
      y: { ticks: { color: "#93a1bd" }, grid: { color: "#223049" } },
    },
  };
}

/* ---------- Vehicle Registration ---------- */
function renderRegister() {
  $("#tab-register").innerHTML = `
    <div class="two-col">
      <div class="card">
        <h3 style="margin-bottom:10px;">Register New Vehicle</h3>
        <form id="registerForm">
          <label>Vehicle Number</label>
          <input type="text" id="f-vehicleNumber" placeholder="TN09AB1234" required />
          <label>Owner Name</label>
          <input type="text" id="f-ownerName" placeholder="Owner name" required />
          <label>Vehicle Type</label>
          <select id="f-vehicleType">
            ${VEHICLE_TYPES.map(t => `<option value="${t}">${t}</option>`).join("")}
          </select>
          <label>Special Requirement (optional)</label>
          <select id="f-specialRequirement">
            <option value="None">None</option>
            <option value="EV Charging">EV Charging</option>
            <option value="Wheelchair Access">Wheelchair Access</option>
            <option value="Covered Parking">Covered Parking</option>
          </select>
          <div class="btn-row">
            <button type="submit" class="btn">Register & Auto-Allocate</button>
          </div>
        </form>
      </div>

      <div class="card">
        <h3 style="margin-bottom:10px;">Last Registered Vehicle</h3>
        ${state.lastAllocation && state.lastAllocation.vehicle
          ? lastAllocationSummary(state.lastAllocation)
          : `<div class="empty-state">No vehicle registered yet.</div>`}
      </div>
    </div>
  `;

  $("#registerForm").addEventListener("submit", e => {
    e.preventDefault();
    const form = {
      vehicleNumber: $("#f-vehicleNumber").value,
      ownerName: $("#f-ownerName").value,
      vehicleType: $("#f-vehicleType").value,
      specialRequirement: $("#f-specialRequirement").value,
    };
    if (!form.vehicleNumber || !form.ownerName) { toast("Please fill in all required fields", "error"); return; }
    registerVehicle(form);
    renderRegister();
    refreshIfVisible(["dashboard", "map", "queue", "search", "billing", "allocation", "dsviz"]);
  });
}

function lastAllocationSummary(alloc) {
  const v = alloc.vehicle, s = alloc.slot;
  if (v.status === "Waiting") {
    return `<div class="kv"><span>Parking ID</span><span><b>${v.parkingId}</b></span></div>
      <div class="kv"><span>Vehicle</span><span>${v.vehicleNumber}</span></div>
      <div class="pill yellow" style="margin-top:10px;">Added to Waiting Queue — no slots available</div>`;
  }
  return `
    <div class="kv"><span>Vehicle Number</span><span><b>${v.vehicleNumber}</b></span></div>
    <div class="kv"><span>Parking ID</span><span><b>${v.parkingId}</b></span></div>
    <div class="kv"><span>Allocated Slot</span><span><b>${s.id}</b> (${s.type})</span></div>
    <div class="kv"><span>Smart Score</span><span><b>${s.score}/100</b></span></div>
    <div style="margin-top:10px;">
      ${(v.allocationReason || []).map(r => `<div style="font-size:12.5px;color:var(--green);">✓ ${r}</div>`).join("")}
    </div>
  `;
}

/* ---------- Smart Slot Allocation ---------- */
function renderAllocation() {
  const vehicleTypeOptions = VEHICLE_TYPES.map(t => `<option value="${t}">${t}</option>`).join("");
  $("#tab-allocation").innerHTML = `
    <div class="ds-badge">Data Structure Used: Priority Queue (Binary Max-Heap) + Array</div>

    <div class="card">
      <h3>Live Slot Score Preview</h3>
      <div class="section-sub">Preview how the Smart Score + Priority Queue would rank currently available slots for a chosen vehicle type. (Preview only — does not allocate.)</div>
      <label>Vehicle Type</label>
      <select id="previewType" style="max-width:240px;">${vehicleTypeOptions}</select>
      <div id="previewResult" style="margin-top:16px;"></div>
    </div>

    <div class="section-title">Most Recent Real Allocation</div>
    <div class="card">
      ${state.lastAllocation && state.lastAllocation.vehicle
        ? renderLastAllocationDetail()
        : `<div class="empty-state">No allocation has occurred yet. Register a vehicle to see it here.</div>`}
    </div>

    <div class="section-title">How Scoring Works</div>
    <div class="mono">Smart Slot Score =
  40% × Distance-from-Entrance Score
+ 20% × Walking-Distance Score
+ 20% × (100 − Congestion)
+ 10% × Vehicle Compatibility Score
+ 10% × Predicted Future Availability

Priority Queue: Insert O(log n)  |  Extract-Max (best slot) O(log n)</div>
  `;

  const renderPreview = () => {
    const vType = $("#previewType").value;
    const available = getAvailableSlots();
    if (available.length === 0) {
      $("#previewResult").innerHTML = `<div class="empty-state">No available slots right now.</div>`;
      return;
    }
    const scored = available.map(s => ({ ...s, sc: computeSmartScore(s, vType) }))
      .sort((a, b) => b.sc.total - a.sc.total);
    $("#previewResult").innerHTML = `
      <table>
        <thead><tr><th>Rank</th><th>Slot</th><th>Type</th><th>Distance</th><th>Congestion</th><th>Score</th></tr></thead>
        <tbody>
          ${scored.slice(0, 8).map((s, i) => `
            <tr>
              <td>${i + 1}</td>
              <td><b>${s.id}</b></td>
              <td>${s.type}</td>
              <td>${s.distance} m</td>
              <td>${s.congestion}%</td>
              <td><span class="pill ${i === 0 ? "green" : "blue"}">${s.sc.total}/100</span></td>
            </tr>`).join("")}
        </tbody>
      </table>
      <div class="pill green" style="margin-top:10px;">Priority Queue selects: ${scored[0].id} (score ${scored[0].sc.total})</div>
    `;
  };
  $("#previewType").addEventListener("change", renderPreview);
  renderPreview();
}

function renderLastAllocationDetail() {
  const { vehicle, slot, scoredList } = state.lastAllocation;
  if (vehicle.status === "Waiting") return `<div class="empty-state">Last registered vehicle went to the waiting queue.</div>`;
  const list = (scoredList || []).slice().sort((a, b) => b.score - a.score);
  return `
    <div class="kv"><span>Vehicle</span><span><b>${vehicle.vehicleNumber}</b> (${vehicle.parkingId})</span></div>
    <div class="kv"><span>Selected Slot</span><span><b>${slot.id}</b> — Score ${slot.score}/100</span></div>
    <div style="margin-top:10px;">${(vehicle.allocationReason || []).map(r => `<div style="font-size:12.5px;color:var(--green);">✓ ${r}</div>`).join("")}</div>
    <div style="margin-top:14px;font-size:12.5px;color:var(--text-dim);">Priority Queue snapshot at allocation time (highest score wins):</div>
    <div class="mono">${list.slice(0, 6).map(s => `${s.id.padEnd(4)} → ${s.score}`).join("\n")}</div>
  `;
}

/* ---------- Parking Map & Navigation ---------- */
function renderMap() {
  $("#tab-map").innerHTML = `
    <div class="legend">
      <span><span class="dot" style="background:var(--green)"></span>Available</span>
      <span><span class="dot" style="background:var(--red)"></span>Occupied</span>
      <span><span class="dot" style="background:var(--yellow)"></span>Reserved / Blocked</span>
      <span><span class="dot" style="border:2px solid var(--blue)"></span>EV</span>
      <span><span class="dot" style="border:2px solid var(--purple)"></span>VIP</span>
      <span><span class="dot" style="border:2px solid var(--gray)"></span>Disabled</span>
    </div>

    <div class="two-col">
      <div>
        ${ZONES.map(zone => `
          <div class="zone-block">
            <div class="zone-label">Zone ${zone}</div>
            <div class="slot-grid">
              ${state.slots.filter(s => s.zone === zone).map(s => slotCell(s)).join("")}
            </div>
          </div>
        `).join("")}
      </div>

      <div>
        <div class="card" id="slotDetailCard">
          <h3>Slot Details</h3>
          <div class="empty-state">Click a slot to see details.</div>
        </div>
        <div class="card" style="margin-top:16px;">
          <h3>🧭 Navigation (Graph + Dijkstra's Algorithm)</h3>
          <div class="section-sub">Select an occupied slot to compute the shortest route from Entrance.</div>
          <select id="navSlotSelect">
            <option value="">— select occupied slot —</option>
            ${state.slots.filter(s => s.status === "Occupied").map(s => `<option value="${s.id}">${s.id} (${s.vehicleNumber || ""})</option>`).join("")}
          </select>
          <div id="navResult" style="margin-top:14px;"></div>
        </div>
      </div>
    </div>
  `;

  $all(".slot").forEach(el => el.addEventListener("click", () => showSlotDetail(el.dataset.id)));
  $("#navSlotSelect").addEventListener("change", e => {
    if (e.target.value) computeRoute(e.target.value);
    else $("#navResult").innerHTML = "";
  });
}

function slotCell(s) {
  const statusClass = s.status.toLowerCase();
  const typeClass = s.type !== "Regular" ? `type-${s.type.toLowerCase()}` : "";
  return `<div class="slot ${statusClass} ${typeClass}" data-id="${s.id}">${s.id}<small>${s.status}</small></div>`;
}

function showSlotDetail(slotId) {
  const s = state.slots.find(x => x.id === slotId);
  if (!s) return;
  const vehicle = s.parkingId ? state.vehicles.get(s.parkingId) : null;
  $("#slotDetailCard").innerHTML = `
    <h3>Slot ${s.id}</h3>
    <div class="kv"><span>Status</span><span><span class="pill ${s.status === "Available" ? "green" : s.status === "Occupied" ? "red" : "yellow"}">${s.status}</span></span></div>
    <div class="kv"><span>Type</span><span>${s.type}</span></div>
    <div class="kv"><span>Vehicle</span><span>${vehicle ? vehicle.vehicleNumber : "—"}</span></div>
    <div class="kv"><span>Distance from Entrance</span><span>${s.distance} m</span></div>
    <div class="kv"><span>Congestion</span><span>${s.congestion}%</span></div>
    <div class="kv"><span>Current Score</span><span>${s.score ? s.score + "/100" : "—"}</span></div>
    ${s.status === "Occupied" ? `<div class="btn-row"><button class="btn danger small" onclick="window.__failSlot('${s.id}')">Simulate Failure Here</button></div>` : ""}
  `;
}
window.__failSlot = id => { triggerSlotFailure(id); renderMap(); refreshIfVisible(["dashboard", "queue", "dsviz"]); };

function computeRoute(slotId) {
  const { path, distance } = state.graph.dijkstra("Entrance", slotId);
  const slot = state.slots.find(s => s.id === slotId);
  const travelTime = (distance / 70).toFixed(1); // ~70 m/min walking assumption
  $("#navResult").innerHTML = `
    <div class="flow-step">${path.map((p, i) => `<span class="route-chip">${p}</span>${i < path.length - 1 ? '<span class="flow-arrow">→</span>' : ""}`).join("")}</div>
    <div class="kv" style="margin-top:10px;"><span>Total Distance</span><span><b>${distance} m</b></span></div>
    <div class="kv"><span>Estimated Travel Time</span><span><b>${travelTime} min</b></span></div>
    <div class="kv"><span>Congestion Level</span><span><b>${slot.congestion < 30 ? "Low" : slot.congestion < 60 ? "Medium" : "High"}</b></span></div>
  `;
}

/* ---------- Waiting Queue ---------- */
function renderQueue() {
  const items = state.waitingQueue.toArray();
  $("#tab-queue").innerHTML = `
    <div class="ds-badge">Data Structure Used: Queue (priority-ordered: Emergency &gt; Disabled &gt; Pre-booked &gt; VIP &gt; Regular)</div>
    <div class="card">
      <div class="card-header">
        <h3>Vehicles Waiting for a Slot (${items.length})</h3>
        <button class="btn small" id="serveNextBtn">Serve Next</button>
      </div>
      ${items.length === 0 ? `<div class="empty-state">Queue is empty — no vehicles waiting.</div>` : `
      <table>
        <thead><tr><th>#</th><th>Parking ID</th><th>Vehicle Number</th><th>Priority</th><th>Waiting Since</th></tr></thead>
        <tbody>
          ${items.map((it, i) => `
            <tr>
              <td>${i + 1}</td>
              <td>${it.parkingId}</td>
              <td>${it.vehicleNumber}</td>
              <td><span class="pill blue">${it.priority}</span></td>
              <td>${fmtTime(it.arrivalTime)}</td>
            </tr>`).join("")}
        </tbody>
      </table>`}
    </div>
  `;
  $("#serveNextBtn").addEventListener("click", () => {
    serveWaitingQueue();
    renderQueue();
    refreshIfVisible(["dashboard", "map", "search", "billing", "dsviz"]);
  });
}

/* ---------- Vehicle Search (Hash Table) ---------- */
function renderSearch() {
  $("#tab-search").innerHTML = `
    <div class="ds-badge">Data Structure Used: Hash Table — average O(1) lookup by Vehicle Number or Parking ID</div>
    <div class="card">
      <h3>Search Vehicle</h3>
      <label>Vehicle Number or Parking ID</label>
      <input type="text" id="searchInput" placeholder="e.g. TN09AB1234 or P1001" />
      <div class="btn-row"><button class="btn" id="searchBtn">Search</button></div>
      <div id="searchResult" style="margin-top:16px;"></div>
    </div>
  `;
  const doSearch = () => {
    const q = $("#searchInput").value.trim();
    const v = state.hashTable.get(q);
    if (!v) { $("#searchResult").innerHTML = `<div class="empty-state">No vehicle found for "${q}".</div>`; return; }
    const slot = v.slotId ? state.slots.find(s => s.id === v.slotId) : null;
    $("#searchResult").innerHTML = `
      <div class="kv"><span>Owner</span><span>${v.ownerName || "—"}</span></div>
      <div class="kv"><span>Vehicle Type</span><span>${v.vehicleType}</span></div>
      <div class="kv"><span>Parking ID</span><span><b>${v.parkingId}</b></span></div>
      <div class="kv"><span>Allocated Slot</span><span>${slot ? slot.id : (v.status === "Waiting" ? "In waiting queue" : "—")}</span></div>
      <div class="kv"><span>Entry Time</span><span>${fmtDateTime(v.entryTime)}</span></div>
      <div class="kv"><span>Status</span><span><span class="pill ${v.status === "Parked" ? "green" : v.status === "Waiting" ? "yellow" : "blue"}">${v.status}</span></span></div>
    `;
  };
  $("#searchBtn").addEventListener("click", doSearch);
  $("#searchInput").addEventListener("keydown", e => { if (e.key === "Enter") doSearch(); });
}

/* ---------- Billing ---------- */
function renderBilling() {
  const parked = [...state.vehicles.values()].filter(v => v.status === "Parked");
  $("#tab-billing").innerHTML = `
    <div class="card">
      <h3>Currently Parked Vehicles</h3>
      ${parked.length === 0 ? `<div class="empty-state">No vehicles currently parked.</div>` : `
      <table>
        <thead><tr><th>Parking ID</th><th>Vehicle</th><th>Slot</th><th>Entry Time</th><th>Elapsed</th><th></th></tr></thead>
        <tbody>
          ${parked.map(v => {
            const elapsedHrs = (Date.now() - v.entryTime) / 3600000;
            return `<tr>
              <td>${v.parkingId}</td>
              <td>${v.vehicleNumber}</td>
              <td>${v.slotId}</td>
              <td>${fmtTime(v.entryTime)}</td>
              <td>${elapsedHrs.toFixed(2)} hr</td>
              <td><button class="btn small danger" onclick="window.__exitVehicle('${v.parkingId}')">Exit &amp; Bill</button></td>
            </tr>`;
          }).join("")}
        </tbody>
      </table>`}
    </div>
    <div id="billReceipt"></div>
  `;
}
window.__exitVehicle = parkingId => {
  const v = exitVehicle(parkingId);
  renderBilling();
  if (v) {
    $("#billReceipt").innerHTML = `
      <div class="section-title">Bill Receipt</div>
      <div class="card" id="printableBill">
        <div class="kv"><span>Parking ID</span><span><b>${v.parkingId}</b></span></div>
        <div class="kv"><span>Vehicle Number</span><span>${v.vehicleNumber}</span></div>
        <div class="kv"><span>Slot</span><span>${v.exitSlotId}</span></div>
        <div class="kv"><span>Entry Time</span><span>${fmtDateTime(v.entryTime)}</span></div>
        <div class="kv"><span>Exit Time</span><span>${fmtDateTime(v.exitTime)}</span></div>
        <div class="kv"><span>Duration</span><span>${v.duration.toFixed(2)} hr</span></div>
        <div class="kv"><span>Rate</span><span>₹${RATE_PER_HOUR}/hour</span></div>
        <div class="kv"><span><b>Total Amount</b></span><span><b>₹${v.amount}</b></span></div>
        <div class="btn-row"><button class="btn small" onclick="window.print()">🖨️ Print Bill</button></div>
      </div>
    `;
  }
  refreshIfVisible(["dashboard", "map", "history", "queue", "dsviz"]);
};

/* ---------- Parking History (Linked List) ---------- */
function renderHistory() {
  const records = state.history.toArray();
  $("#tab-history").innerHTML = `
    <div class="ds-badge">Data Structure Used: Singly Linked List — insert-at-head O(1), traverse O(n)</div>
    <div class="card">
      <h3>Linked List Chain</h3>
      ${records.length === 0 ? `<div class="empty-state">No history yet.</div>` :
        `<div class="mono">${records.slice(0, 10).map(r => `[ ${r.parkingId} ]`).join(" → ")} → NULL</div>`}
    </div>
    <div class="section-title">History Records</div>
    <div class="card">
      ${records.length === 0 ? `<div class="empty-state">Exit a vehicle from Billing to generate history.</div>` : `
      <table>
        <thead><tr><th>Parking ID</th><th>Vehicle</th><th>Slot</th><th>Entry</th><th>Exit</th><th>Duration</th><th>Amount</th><th></th></tr></thead>
        <tbody>
          ${records.map(r => `
            <tr>
              <td>${r.parkingId}</td>
              <td>${r.vehicleNumber}</td>
              <td>${r.exitSlotId}</td>
              <td>${fmtTime(r.entryTime)}</td>
              <td>${fmtTime(r.exitTime)}</td>
              <td>${r.duration.toFixed(2)} hr</td>
              <td>₹${r.amount}</td>
              <td><button class="btn small secondary" onclick="window.__removeHistory('${r.parkingId}')">Remove</button></td>
            </tr>`).join("")}
        </tbody>
      </table>`}
    </div>
  `;
}
window.__removeHistory = id => { state.history.removeById(id); renderHistory(); refreshIfVisible(["dsviz"]); };

/* ---------- Predictive Analytics ---------- */
function renderPredict() {
  const peak = DEMAND_BANDS.reduce((a, b) => (b.occupancy > a.occupancy ? b : a));
  $("#tab-predict").innerHTML = `
    <div class="card">
      <h3>Predicted Demand by Time Band <span style="font-weight:400;color:var(--text-dim);font-size:12px;">(simulated / demo data)</span></h3>
      <div class="chart-box"><canvas id="chartPredict"></canvas></div>
      <div class="kv" style="margin-top:14px;"><span>Peak Parking Period</span><span><b>${peak.label}</b></span></div>
      <div class="kv"><span>Predicted Occupancy</span><span><b>${peak.occupancy}%</b></span></div>
      <div class="pill yellow" style="margin-top:10px;">High parking demand expected at ${peak.label}. Reserve additional slots and redirect incoming vehicles to Zone B.</div>
    </div>

    <div class="section-title">What-If Simulation</div>
    <div class="card">
      <div class="grid grid-2">
        <div>
          <label>Incoming Vehicles</label>
          <input type="number" id="whatifIncoming" value="50" min="0" />
        </div>
        <div>
          <label>Available Slots (override, optional)</label>
          <input type="number" id="whatifSlots" placeholder="${getAvailableSlots().length} (current)" />
        </div>
      </div>
      <div class="btn-row">
        <button class="btn" id="whatifRunBtn">Run Simulation</button>
        <button class="btn secondary" id="whatifPeakBtn">Simulate Peak Hour</button>
      </div>
      <div id="whatifResult" style="margin-top:14px;"></div>
    </div>
  `;

  destroyChart("predict");
  state.charts.predict = new Chart($("#chartPredict"), {
    type: "bar",
    data: { labels: DEMAND_BANDS.map(b => b.label), datasets: [{ label: "Predicted Occupancy %", data: DEMAND_BANDS.map(b => b.occupancy), backgroundColor: "#4f8cff" }] },
    options: chartOpts(),
  });

  $("#whatifRunBtn").addEventListener("click", () => {
    const incoming = parseInt($("#whatifIncoming").value) || 0;
    const availSlots = parseInt($("#whatifSlots").value) || getAvailableSlots().length;
    let html;
    if (incoming > availSlots) {
      const overflow = incoming - availSlots;
      html = `<div class="pill red">Parking capacity may be insufficient.</div>
        <div class="kv" style="margin-top:10px;"><span>Recommendation</span><span><b>Redirect ${overflow} vehicles to Zone B / overflow parking.</b></span></div>`;
    } else {
      html = `<div class="pill green">Sufficient capacity for incoming vehicles.</div>
        <div class="kv" style="margin-top:10px;"><span>Slack</span><span><b>${availSlots - incoming} slots remaining after allocation.</b></span></div>`;
    }
    $("#whatifResult").innerHTML = html;
  });

  $("#whatifPeakBtn").addEventListener("click", () => {
    simulatePeakHour();
    toast("Peak hour simulated — congestion & occupancy increased", "warn");
    renderPredict();
    refreshIfVisible(["dashboard", "map", "dsviz"]);
  });
}

function simulatePeakHour() {
  state.slots.forEach(s => {
    s.congestion = clamp(s.congestion + randInt(10, 30), 0, 95);
    if (s.status === "Available" && Math.random() < 0.4) {
      s.status = "Occupied";
      const pseudoId = `SIM-${randInt(1000, 9999)}`;
      s.vehicleNumber = pseudoId;
      s.parkingId = null;
    }
  });
}

/* ---------- Algorithm Comparison ---------- */
function renderCompare() {
  $("#tab-compare").innerHTML = `
    <div class="card">
      <div class="card-header">
        <h3>Compare Parking Allocation Algorithms</h3>
        <button class="btn small" id="runCompareBtn">Run Comparison</button>
      </div>
      <div class="section-sub">Simulates 12 incoming vehicles against a snapshot of the current slot layout for each strategy. Values are generated live from the simulation, not hard-coded.</div>
      <div id="compareTableWrap">${state.algoStats ? compareTable(state.algoStats) : `<div class="empty-state">Click "Run Comparison" to generate results.</div>`}</div>
    </div>
    ${state.algoStats ? `
    <div class="section-title">Visual Comparison</div>
    <div class="grid grid-2">
      <div class="card"><h3>Search Time (ms)</h3><div class="chart-box small"><canvas id="chartCompareSearch"></canvas></div></div>
      <div class="card"><h3>Space Utilization (%)</h3><div class="chart-box small"><canvas id="chartCompareUtil"></canvas></div></div>
    </div>` : ""}
  `;

  $("#runCompareBtn").addEventListener("click", () => { runAlgorithmComparison(); renderCompare(); });

  if (state.algoStats) {
    const labels = Object.keys(state.algoStats);
    destroyChart("compareSearch"); destroyChart("compareUtil");
    state.charts.compareSearch = new Chart($("#chartCompareSearch"), {
      type: "bar",
      data: { labels, datasets: [{ label: "Search Time (ms)", data: labels.map(l => state.algoStats[l].searchTime), backgroundColor: "#7c5cff" }] },
      options: chartOpts(),
    });
    state.charts.compareUtil = new Chart($("#chartCompareUtil"), {
      type: "bar",
      data: { labels, datasets: [{ label: "Space Utilization %", data: labels.map(l => state.algoStats[l].utilization), backgroundColor: "#33c481" }] },
      options: chartOpts(),
    });
  }
}

function compareTable(stats) {
  return `
    <table>
      <thead><tr><th>Algorithm</th><th>Search Time (ms)</th><th>Avg Waiting/Travel Time (min)</th><th>Space Utilization</th></tr></thead>
      <tbody>
        ${Object.entries(stats).map(([name, s]) => `
          <tr>
            <td><b>${name}</b>${name === "Proposed Algorithm" ? ' <span class="pill green">Best</span>' : ""}</td>
            <td>${s.searchTime}</td>
            <td>${s.waitingTime}</td>
            <td>${s.utilization}%</td>
          </tr>`).join("")}
      </tbody>
    </table>
  `;
}

/* ---------- Data Structures Visualizer ---------- */
function renderDSViz() {
  const available = getAvailableSlots();
  const pqSnapshot = available.map(s => ({ id: s.id, score: s.score || 0 })).sort((a, b) => b.score - a.score).slice(0, 6);
  const waiting = state.waitingQueue.toArray();
  const history = state.history.toArray();

  $("#tab-dsviz").innerHTML = `
    <div class="grid grid-2">
      <div class="card">
        <h3>Array — Parking Slot Management</h3>
        <div class="section-sub">Direct index access O(1) · Linear scan O(n)</div>
        <div class="mono">${state.slots.slice(0, 12).map(s => `${s.id}:${s.status[0]}`).join("  ")} ...</div>
      </div>

      <div class="card">
        <h3>Priority Queue — Best Slot Selection</h3>
        <div class="section-sub">Binary max-heap · Insert O(log n) · Extract-Max O(log n)</div>
        <div class="mono">${pqSnapshot.length ? pqSnapshot.map(s => `${s.id.padEnd(4)} – ${s.score}`).join("\n") : "No scored slots yet — visit Allocation tab."}</div>
        <div class="btn-row"><button class="btn small" id="pqExtractBtn">Preview Extract Best Slot</button></div>
        <div id="pqExtractResult" style="margin-top:8px;font-size:12.5px;"></div>
      </div>

      <div class="card">
        <h3>Queue — Waiting Vehicles</h3>
        <div class="section-sub">FIFO within priority class · Enqueue O(1) · Dequeue O(n)</div>
        <div class="mono">${waiting.length ? waiting.map(w => `${w.parkingId} (${w.priority})`).join("\n") : "Queue empty"}</div>
      </div>

      <div class="card">
        <h3>Hash Table — Vehicle Search</h3>
        <div class="section-sub">Average O(1) lookup by Vehicle Number / Parking ID</div>
        <div class="mono">Entries stored: ${state.hashTable.size()}
Keys are both Vehicle Number and Parking ID → same record</div>
      </div>

      <div class="card">
        <h3>Linked List — Parking History</h3>
        <div class="section-sub">Insert-at-head O(1) · Traverse O(n)</div>
        <div class="mono">${history.length ? history.slice(0, 6).map(r => `[${r.parkingId}]`).join(" → ") + " → NULL" : "No history yet"}</div>
      </div>

      <div class="card">
        <h3>Graph + Dijkstra — Navigation</h3>
        <div class="section-sub">Shortest path from Entrance to any slot</div>
        <div class="mono">Nodes: ${state.graph.adj.size}
Edges: ${[...state.graph.adj.values()].reduce((a, arr) => a + arr.length, 0) / 2}</div>
      </div>
    </div>

    <div class="section-title">Tree — Parking Hierarchy</div>
    <div class="card">${renderTreeHTML(state.tree)}</div>
  `;

  $("#pqExtractBtn").addEventListener("click", () => {
    if (pqSnapshot.length === 0) { $("#pqExtractResult").textContent = "Nothing to extract."; return; }
    $("#pqExtractResult").innerHTML = `<span class="pill green">Extracted: ${pqSnapshot[0].id} (score ${pqSnapshot[0].score})</span> — this is a preview only, no slot was actually allocated.`;
  });
}

function renderTreeHTML(node) {
  if (!node.children || node.children.length === 0) return `<span class="node-label">${node.name}</span>`;
  return `<span class="node-label">${node.name}</span>
    <ul class="tree">${node.children.map(c => `<li>${renderTreeHTML(c)}</li>`).join("")}</ul>`;
}

/* ---------- Admin / Simulation Panel ---------- */
function renderAdmin() {
  const occupiedSlots = state.slots.filter(s => s.status === "Occupied");
  const availableSlots = getAvailableSlots();
  $("#tab-admin").innerHTML = `
    <div class="grid grid-3">
      <div class="card">
        <h3>Vehicles</h3>
        <div class="btn-row">
          <button class="btn small" id="addRandomVehicleBtn">Add Random Vehicle</button>
          <button class="btn small danger" id="removeRandomVehicleBtn">Exit Random Parked Vehicle</button>
        </div>
      </div>
      <div class="card">
        <h3>Slots</h3>
        <div class="btn-row">
          <button class="btn small" id="occupySlotBtn">Occupy Random Available Slot</button>
          <button class="btn small secondary" id="freeSlotBtn">Free Random Occupied Slot</button>
          <button class="btn small secondary" id="reserveSlotBtn">Reserve Random Available Slot</button>
        </div>
      </div>
      <div class="card">
        <h3>Waiting Queue</h3>
        <div class="btn-row">
          <button class="btn small" id="addWaitingBtn">Add Random Waiting Vehicle</button>
          <button class="btn small" id="serveQueueBtn">Serve Next in Queue</button>
        </div>
      </div>
      <div class="card">
        <h3>Peak &amp; Failure Simulation</h3>
        <div class="btn-row">
          <button class="btn small danger" id="peakBtn">Simulate Peak Hour</button>
          <select id="failSlotSelect" style="max-width:160px;">
            <option value="">— pick occupied slot —</option>
            ${occupiedSlots.map(s => `<option value="${s.id}">${s.id}</option>`).join("")}
          </select>
          <button class="btn small danger" id="failBtn">Trigger Slot Failure / Reallocation</button>
        </div>
      </div>
      <div class="card">
        <h3>Bulk / Reset</h3>
        <div class="btn-row">
          <button class="btn small secondary" id="randomizeBtn">Generate Random Parking Data</button>
          <button class="btn small danger" id="resetBtn">Reset Simulation</button>
        </div>
      </div>
      <div class="card">
        <h3>Time</h3>
        <div class="section-sub">Fast-forward parked vehicles' entry time to demo billing.</div>
        <div class="btn-row">
          <button class="btn small" id="ff1Btn">+1 hour</button>
          <button class="btn small" id="ff3Btn">+3 hours</button>
        </div>
      </div>
    </div>

    <div class="section-title">Recent Reallocation Log</div>
    <div class="card">
      ${state.lastFailureLog.length === 0 ? `<div class="empty-state">No failure/reallocation events yet.</div>` :
        state.lastFailureLog.map(l => `<div class="kv"><span>${fmtTime(l.time)}</span><span>${l.text}</span></div>`).join("")}
    </div>
  `;

  const refresh = () => { renderAdmin(); refreshIfVisible(["dashboard", "map", "queue", "search", "billing", "history", "dsviz"]); };

  $("#addRandomVehicleBtn").addEventListener("click", () => {
    registerVehicle({
      vehicleNumber: `TN${randInt(10, 99)}${choice(["AB","CD","EF","GH"])}${randInt(1000, 9999)}`,
      ownerName: choice(["R. Kumar", "S. Priya", "A. Sharma", "M. Iqbal", "D. Rao"]),
      vehicleType: choice(VEHICLE_TYPES),
      specialRequirement: "None",
    });
    refresh();
  });

  $("#removeRandomVehicleBtn").addEventListener("click", () => {
    const parked = [...state.vehicles.values()].filter(v => v.status === "Parked");
    if (parked.length === 0) { toast("No parked vehicles to exit", "warn"); return; }
    exitVehicle(choice(parked).parkingId);
    refresh();
  });

  $("#occupySlotBtn").addEventListener("click", () => {
    if (availableSlots.length === 0) { toast("No available slots", "warn"); return; }
    const s = choice(availableSlots);
    s.status = "Occupied"; s.vehicleNumber = `SIM-${randInt(1000, 9999)}`; s.parkingId = null;
    toast(`${s.id} manually occupied`, "success");
    refresh();
  });

  $("#freeSlotBtn").addEventListener("click", () => {
    const occ = state.slots.filter(s => s.status === "Occupied");
    if (occ.length === 0) { toast("No occupied slots", "warn"); return; }
    const s = choice(occ);
    s.status = "Available"; s.vehicleNumber = null; s.parkingId = null;
    toast(`${s.id} freed`, "success");
    refresh();
  });

  $("#reserveSlotBtn").addEventListener("click", () => {
    if (availableSlots.length === 0) { toast("No available slots", "warn"); return; }
    const s = choice(availableSlots);
    s.status = "Reserved";
    toast(`${s.id} reserved`, "success");
    refresh();
  });

  $("#addWaitingBtn").addEventListener("click", () => {
    const parkingId = `P${state.parkingIdCounter++}`;
    const vehicleNumber = `TN${randInt(10, 99)}${choice(["AB","CD","EF"])}${randInt(1000, 9999)}`;
    const vType = choice(VEHICLE_TYPES);
    const vehicle = { parkingId, vehicleNumber, ownerName: "Waiting Demo", vehicleType: vType, entryTime: Date.now(), slotId: null, status: "Waiting" };
    state.vehicles.set(parkingId, vehicle);
    state.hashTable.set(vehicleNumber, vehicle); state.hashTable.set(parkingId, vehicle);
    state.waitingQueue.enqueue({ parkingId, vehicleNumber, priority: vType === "VIP" ? "VIP" : vType === "Disabled" ? "Disabled" : "Regular" });
    toast(`${parkingId} added to waiting queue`, "success");
    refresh();
  });

  $("#serveQueueBtn").addEventListener("click", () => { serveWaitingQueue(); refresh(); });
  $("#peakBtn").addEventListener("click", () => { simulatePeakHour(); toast("Peak hour simulated", "warn"); refresh(); });
  $("#failBtn").addEventListener("click", () => {
    const id = $("#failSlotSelect").value;
    if (!id) { toast("Select an occupied slot first", "warn"); return; }
    triggerSlotFailure(id);
    refresh();
  });
  $("#randomizeBtn").addEventListener("click", () => {
    state.slots.forEach(s => {
      s.status = choice(["Available", "Available", "Occupied", "Occupied", "Reserved"]);
      s.congestion = randInt(5, 90);
      if (s.status !== "Occupied") { s.vehicleNumber = null; s.parkingId = null; }
    });
    toast("Random parking data generated", "success");
    refresh();
  });
  $("#resetBtn").addEventListener("click", () => { resetSimulation(); refresh(); });
  $("#ff1Btn").addEventListener("click", () => { fastForward(1); refresh(); });
  $("#ff3Btn").addEventListener("click", () => { fastForward(3); refresh(); });
}

function fastForward(hours) {
  let count = 0;
  [...state.vehicles.values()].filter(v => v.status === "Parked").forEach(v => {
    v.entryTime -= hours * 3600000;
    count++;
  });
  toast(`Fast-forwarded ${count} parked vehicle(s) by ${hours}h`, "success");
}

/* ---------- Project Info ---------- */
function renderInfo() {
  $("#tab-info").innerHTML = `
    <div class="card">
      <h3>Problem Statement</h3>
      <p style="color:var(--text-dim);font-size:13.5px;line-height:1.6;">
        Existing parking systems often lack intelligent real-time allocation, efficient data management,
        and predictive demand handling. SmartPark AI addresses this by combining several advanced data
        structures and algorithms into one interactive simulation.
      </p>
    </div>
    <div class="section-title">Objectives</div>
    <div class="card">
      <ul style="color:var(--text-dim);font-size:13.5px;line-height:1.9;">
        <li>Efficiently manage parking spaces</li>
        <li>Reduce vehicle waiting time</li>
        <li>Optimize parking allocation using a Smart Score + Priority Queue</li>
        <li>Demonstrate advanced data structures in a live, interactive way</li>
        <li>Predict parking demand using simulated historical data</li>
        <li>Improve space utilization</li>
      </ul>
    </div>
    <div class="section-title">Modules</div>
    <div class="card">
      <div class="kv"><span>1. Smart Parking Registration &amp; Slot Allocation</span><span>Array, Priority Queue</span></div>
      <div class="kv"><span>2. Intelligent Navigation &amp; Parking Operations</span><span>Graph, Dijkstra's Algorithm, Queue</span></div>
      <div class="kv"><span>3. Billing, Analytics &amp; Smart Monitoring</span><span>Linked List, Hash Table, Tree</span></div>
    </div>
    <div class="section-title">Data Structure Index</div>
    <div class="card">
      <div class="kv"><span>Smart Slot Allocation</span><span class="mono" style="padding:4px 8px;">Priority Queue + Array</span></div>
      <div class="kv"><span>Vehicle Search</span><span class="mono" style="padding:4px 8px;">Hash Table</span></div>
      <div class="kv"><span>Navigation</span><span class="mono" style="padding:4px 8px;">Graph + Dijkstra</span></div>
      <div class="kv"><span>Waiting Management</span><span class="mono" style="padding:4px 8px;">Queue</span></div>
      <div class="kv"><span>Parking History</span><span class="mono" style="padding:4px 8px;">Linked List</span></div>
      <div class="kv"><span>Parking Hierarchy</span><span class="mono" style="padding:4px 8px;">Tree</span></div>
    </div>
  `;
}

/* ---------------- Renderer Registry ---------------- */
const RENDERERS = {
  dashboard: renderDashboard,
  register: renderRegister,
  allocation: renderAllocation,
  map: renderMap,
  queue: renderQueue,
  search: renderSearch,
  billing: renderBilling,
  history: renderHistory,
  predict: renderPredict,
  compare: renderCompare,
  dsviz: renderDSViz,
  admin: renderAdmin,
  info: renderInfo,
};

/* ---------------- Init ---------------- */
function initNav() {
  $all(".nav-item").forEach(btn => btn.addEventListener("click", () => setActiveTab(btn.dataset.tab)));
}

function tickClock() {
  $("#clock").textContent = new Date().toLocaleString();
}

document.addEventListener("DOMContentLoaded", () => {
  initNav();
  tickClock();
  setInterval(tickClock, 1000);
  setActiveTab("dashboard");
});
