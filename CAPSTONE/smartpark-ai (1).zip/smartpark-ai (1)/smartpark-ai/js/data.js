/* =========================================================
   SmartPark AI — Initial Demo Data & State
   All values are SIMULATED for demonstration purposes.
   ========================================================= */

const ZONES = ["A", "B", "C", "D"];
const SLOTS_PER_ZONE = 6; // 4 zones x 6 = 24 slots (scaled down for a clean demo UI)

const SPECIAL_SLOT_PLAN = {
  // a few designated special slots per zone, rest are Regular
  A: { 1: "EV" },
  B: { 1: "VIP" },
  C: { 1: "Disabled" },
  D: { 1: "EV" },
};

function randInt(min, max) { return Math.floor(Math.random() * (max - min + 1)) + min; }
function choice(arr) { return arr[randInt(0, arr.length - 1)]; }

function buildInitialSlots() {
  const slots = [];
  ZONES.forEach(zone => {
    for (let n = 1; n <= SLOTS_PER_ZONE; n++) {
      const id = `${zone}${n}`;
      const specialType = SPECIAL_SLOT_PLAN[zone]?.[n] || "Regular";
      const distance = randInt(20, 160);       // meters from entrance junction
      const walkDistance = randInt(10, 90);     // meters to building entrance
      const congestion = randInt(5, 80);        // % congestion around the slot
      const occupiedSeed = Math.random() < 0.5; // ~50% start occupied for a lively demo
      slots.push({
        id,
        zone,
        type: specialType,           // Regular | EV | VIP | Disabled
        status: occupiedSeed ? "Occupied" : "Available", // Available | Occupied | Reserved
        vehicleNumber: null,
        parkingId: null,
        distance,
        walkDistance,
        congestion,
        score: 0,
      });
    }
  });
  return slots;
}

function buildGraph(slots) {
  const graph = new ParkingGraph();
  graph.addNode("Entrance");
  ZONES.forEach(zone => {
    const junction = `Junction-${zone}`;
    graph.addEdge("Entrance", junction, randInt(40, 100));
    slots.filter(s => s.zone === zone).forEach(s => {
      graph.addEdge(junction, s.id, s.distance);
    });
  });
  // connect junctions to each other for realism (ring layout)
  for (let i = 0; i < ZONES.length; i++) {
    const a = `Junction-${ZONES[i]}`;
    const b = `Junction-${ZONES[(i + 1) % ZONES.length]}`;
    graph.addEdge(a, b, randInt(30, 70));
  }
  return graph;
}

function buildTree(slots) {
  const root = new TreeNode("Parking Area");
  ZONES.forEach(zone => {
    const zoneNode = root.addChild(new TreeNode(`Zone ${zone}`));
    slots.filter(s => s.zone === zone).forEach(s => {
      const slotNode = zoneNode.addChild(new TreeNode(s.id, { status: s.status }));
      slotNode.addChild(new TreeNode(s.type));
    });
  });
  return root;
}

// Simulated historical occupancy by time band -> used for prediction & charts
const DEMAND_BANDS = [
  { label: "8–10 AM", occupancy: 40 },
  { label: "10–12 PM", occupancy: 65 },
  { label: "12–2 PM", occupancy: 88 },
  { label: "2–4 PM", occupancy: 70 },
  { label: "4–6 PM", occupancy: 92 },
  { label: "6–8 PM", occupancy: 76 },
];

const VEHICLE_TYPES = ["Car", "Bike", "SUV", "EV", "Disabled", "VIP"];

const RATE_PER_HOUR = 20; // ₹20/hour flat demo rate
