/* =========================================================
   SmartPark AI — Core Data Structure Implementations
   Every structure here is a REAL implementation (not a mock)
   used live by the application logic in app.js
   ========================================================= */

/* ---------- 1. PRIORITY QUEUE (Binary Max-Heap) ----------
   Used for: Smart Slot Allocation
   Higher smartScore = higher priority
   Insert: O(log n)   Extract-Max: O(log n)               */
class PriorityQueue {
  constructor() {
    this.heap = []; // array of {id, score, payload}
  }
  size() { return this.heap.length; }
  isEmpty() { return this.heap.length === 0; }
  clear() { this.heap = []; }

  insert(item) {
    this.heap.push(item);
    this._bubbleUp(this.heap.length - 1);
  }

  extractMax() {
    if (this.isEmpty()) return null;
    const top = this.heap[0];
    const last = this.heap.pop();
    if (this.heap.length > 0) {
      this.heap[0] = last;
      this._bubbleDown(0);
    }
    return top;
  }

  peek() { return this.isEmpty() ? null : this.heap[0]; }

  toSortedArray() {
    return [...this.heap].sort((a, b) => b.score - a.score);
  }

  _bubbleUp(i) {
    while (i > 0) {
      const parent = Math.floor((i - 1) / 2);
      if (this.heap[parent].score >= this.heap[i].score) break;
      [this.heap[parent], this.heap[i]] = [this.heap[i], this.heap[parent]];
      i = parent;
    }
  }

  _bubbleDown(i) {
    const n = this.heap.length;
    while (true) {
      let largest = i;
      const l = 2 * i + 1, r = 2 * i + 2;
      if (l < n && this.heap[l].score > this.heap[largest].score) largest = l;
      if (r < n && this.heap[r].score > this.heap[largest].score) largest = r;
      if (largest === i) break;
      [this.heap[largest], this.heap[i]] = [this.heap[i], this.heap[largest]];
      i = largest;
    }
  }
}

/* ---------- 2. QUEUE (with priority classes) ----------
   Used for: Waiting Vehicles
   Priority order: Emergency > Disabled > Pre-booked > VIP > Regular
   Enqueue: O(1)   Dequeue (eligible): O(n) scan for highest priority class,
   FIFO within the same class                                          */
class WaitingQueue {
  constructor() {
    this.items = []; // {parkingId, vehicleNumber, priority, arrivalTime}
    this.priorityRank = { Emergency: 1, Disabled: 2, "Pre-booked": 3, VIP: 4, Regular: 5 };
  }
  size() { return this.items.length; }
  isEmpty() { return this.items.length === 0; }

  enqueue(item) {
    this.items.push({ ...item, arrivalTime: Date.now() });
  }

  // Removes & returns the highest-priority (lowest rank number), earliest-arrival vehicle
  dequeue() {
    if (this.isEmpty()) return null;
    let bestIdx = 0;
    for (let i = 1; i < this.items.length; i++) {
      const a = this.items[i], b = this.items[bestIdx];
      const rankA = this.priorityRank[a.priority] ?? 5;
      const rankB = this.priorityRank[b.priority] ?? 5;
      if (rankA < rankB || (rankA === rankB && a.arrivalTime < b.arrivalTime)) {
        bestIdx = i;
      }
    }
    return this.items.splice(bestIdx, 1)[0];
  }

  removeByParkingId(parkingId) {
    const idx = this.items.findIndex(i => i.parkingId === parkingId);
    if (idx >= 0) return this.items.splice(idx, 1)[0];
    return null;
  }

  toArray() {
    return [...this.items].sort((a, b) => {
      const rankA = this.priorityRank[a.priority] ?? 5;
      const rankB = this.priorityRank[b.priority] ?? 5;
      if (rankA !== rankB) return rankA - rankB;
      return a.arrivalTime - b.arrivalTime;
    });
  }
}

/* ---------- 3. SINGLY LINKED LIST ----------
   Used for: Parking History
   Insert at head: O(1)   Traverse: O(n)                */
class ListNode {
  constructor(data) { this.data = data; this.next = null; }
}
class LinkedList {
  constructor() { this.head = null; this.count = 0; }
  size() { return this.count; }

  insertFront(data) {
    const node = new ListNode(data);
    node.next = this.head;
    this.head = node;
    this.count++;
  }

  removeById(id, idField = "parkingId") {
    let prev = null, curr = this.head;
    while (curr) {
      if (curr.data[idField] === id) {
        if (prev) prev.next = curr.next; else this.head = curr.next;
        this.count--;
        return curr.data;
      }
      prev = curr; curr = curr.next;
    }
    return null;
  }

  toArray() {
    const arr = [];
    let curr = this.head;
    while (curr) { arr.push(curr.data); curr = curr.next; }
    return arr;
  }
}

/* ---------- 4. HASH TABLE (JS Map used as a hash table) ----------
   Used for: Vehicle Search
   Key = Vehicle Number OR Parking ID
   Average Insert/Search/Delete: O(1)                              */
class VehicleHashTable {
  constructor() { this.map = new Map(); }
  set(key, value) { this.map.set(key.toUpperCase(), value); }
  get(key) { return this.map.get((key || "").toUpperCase()) || null; }
  delete(key) { return this.map.delete((key || "").toUpperCase()); }
  values() { return [...this.map.values()]; }
  size() { return this.map.size; }
}

/* ---------- 5. GRAPH + DIJKSTRA'S ALGORITHM ----------
   Used for: Parking Navigation / Shortest Path
   Nodes = Entrance, Junctions, Parking Slots
   Edge weight = distance (meters), adjusted by congestion
   Dijkstra: O((V+E) log V) with a simple array-based priority pick */
class ParkingGraph {
  constructor() { this.adj = new Map(); }

  addNode(id) { if (!this.adj.has(id)) this.adj.set(id, []); }

  addEdge(a, b, weight) {
    this.addNode(a); this.addNode(b);
    this.adj.get(a).push({ node: b, weight });
    this.adj.get(b).push({ node: a, weight });
  }

  dijkstra(start, end) {
    const dist = new Map();
    const prev = new Map();
    const visited = new Set();
    for (const node of this.adj.keys()) dist.set(node, Infinity);
    dist.set(start, 0);

    while (visited.size < this.adj.size) {
      // pick unvisited node with smallest distance
      let u = null, best = Infinity;
      for (const [node, d] of dist.entries()) {
        if (!visited.has(node) && d < best) { best = d; u = node; }
      }
      if (u === null) break;
      visited.add(u);
      if (u === end) break;

      for (const { node: v, weight } of this.adj.get(u) || []) {
        if (visited.has(v)) continue;
        const alt = dist.get(u) + weight;
        if (alt < dist.get(v)) {
          dist.set(v, alt);
          prev.set(v, u);
        }
      }
    }

    // reconstruct path
    const path = [];
    let curr = end;
    if (!prev.has(curr) && curr !== start) return { path: [], distance: Infinity };
    while (curr !== undefined) {
      path.unshift(curr);
      if (curr === start) break;
      curr = prev.get(curr);
    }
    return { path, distance: dist.get(end) };
  }
}

/* ---------- 6. TREE (Parking Hierarchy) ----------
   Used for: Organized parking information
   Parking Area -> Zones -> Slots -> Vehicle Type          */
class TreeNode {
  constructor(name, meta = {}) {
    this.name = name;
    this.meta = meta;
    this.children = [];
  }
  addChild(node) { this.children.push(node); return node; }
}

/* ---------- 7. ARRAY-BASED SLOT MANAGEMENT ----------
   Used for: Parking Slots themselves — direct-index O(1) access,
   O(n) linear scan for "first available" (used in Algorithm Comparison) */
